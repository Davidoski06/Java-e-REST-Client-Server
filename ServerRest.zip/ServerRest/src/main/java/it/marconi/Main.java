package it.marconi;

import org.glassfish.jersey.server.ResourceConfig;
import org.glassfish.jersey.jetty.JettyHttpContainerFactory;
import javax.ws.rs.ApplicationPath;
import java.net.URI;

@ApplicationPath("/api")  //--Imposta il prefisso dell'URL per le risorse REST
public class Main extends ResourceConfig {
    public Main() {
        //--Registrazione delle risorse REST
        packages("it.marconi");
    }

    public static void main(String[] args) {
        //--URI del server
        URI uri = URI.create("http://localhost:8080/");
        
        //--Creazione del server Jetty con la configurazione di Jersey
        JettyHttpContainerFactory.createServer(uri, new Main());
        System.out.println("Server started at " + uri);
    }
}
